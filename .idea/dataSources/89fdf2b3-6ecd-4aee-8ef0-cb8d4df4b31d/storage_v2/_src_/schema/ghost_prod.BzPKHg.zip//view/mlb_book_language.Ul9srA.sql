create definer = root@`%` view mlb_book_language as
select distinct `ghost_prod`.`mlb_book`.`language` AS `name`
from `ghost_prod`.`mlb_book`;

