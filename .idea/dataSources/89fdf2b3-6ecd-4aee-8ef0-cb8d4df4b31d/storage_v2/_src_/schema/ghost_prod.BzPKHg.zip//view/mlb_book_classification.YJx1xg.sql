create definer = root@`%` view mlb_book_classification as
select distinct `ghost_prod`.`mlb_book`.`classification` AS `name`
from `ghost_prod`.`mlb_book`;

