create definer = root@`%` view mlb_book_publishhouse as
select distinct `ghost_prod`.`mlb_book`.`publishhouse` AS `name`
from `ghost_prod`.`mlb_book`;

